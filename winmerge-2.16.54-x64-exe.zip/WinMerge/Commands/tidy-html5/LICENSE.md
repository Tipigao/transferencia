# HTML Tidy

## HTML parser and pretty printer

Copyright (c) 1998-2016 World Wide Web Consortium
(Massachusetts Institute of Technology, European Research 
Consortium for Informatics and Mathematics, Keio University).
All Rights Reserved.

Additional contributions (c) 2001-2016 University of Toronto, Terry Teague, 
@geoffmcl, HTACG, and others.

### Contributing Author(s):

  Dave Raggett <dsr@w3.org>

The contributing author(s) would like to thank all those who
helped with testing, bug fixes and suggestions for improvements. 
This wouldn't have been possible without your help.

## COPYRIGHT NOTICE:

This software and documentation is provided "as is," and
the copyright holders and contributing author(s) make no
representations or warranties, express or implied, including
but not limited to, warranties of merchantability or fitness
for any particular purpose or that the use of the software or
documentation will not infringe any third party patents,
copyrights, trademarks or other rights. 

The copyright holders and contributing author(s) will not be held
liable for any direct, indirect, special or consequential damages
arising out of any use of the software or documentation, even if
advised of the possibility of such damage.

Permission is hereby granted to use, copy, modify, and distribute
this source code, or portions hereof, documentation and executables,
for any purpose, without fee, subject to the following restrictions:

1. The origin of this source code must not be misrepresented.
2. Altered versions must be plainly marked as such and must
not be misrepresented as being the original source.
3. This Copyright notice may not be removed or altered from any
source or altered source distribution.

The copyright holders and contributing author(s) specifically
permit, without fee, and encourage the use of this source code
as a component for supporting the Hypertext Markup Language in
commercial products. If you use this source code in a product,
acknowledgement is not required but would be appreciated.
